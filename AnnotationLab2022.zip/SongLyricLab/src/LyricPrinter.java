import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;

import annotations.Block;

public class LyricPrinter {

	public static void main(String[] args) throws Exception {
		
		printSong("blackpink.bornpink.Song1");

	}

	private static void emergencySort(Method[] methodList)
	{
		Arrays.sort(methodList, new Comparator<Method>() {@Override
			public int compare(Method o1, Method o2) {
				
				if (o1.isAnnotationPresent(Block.class) && o2.isAnnotationPresent(Block.class))
				{
					Block b1 = (Block) o1.getAnnotation(Block.class);
					Block b2 = (Block) o2.getAnnotation(Block.class);
					if (b1.value()>b2.value())
					{
						return 1;
					}
					
					if (b1.value()<b2.value())
					{
						return -1;
					}
				}
				
				return 0;
			}
			});
	}
	
	private static void printSong(String song) throws Exception
	{
		
	}
	
}
