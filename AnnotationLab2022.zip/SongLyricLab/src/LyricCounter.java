

public class LyricCounter 
{
public static void main(String[] args) throws Exception {
		
		int count = countLyrics("JISOO", "blackpink.bornpink.Song1");
		System.out.println("JISOO sang "+count+" lines");
		
		count = countLyrics("JENNIE", "blackpink.bornpink.Song1");
		System.out.println("JENNIE sang "+count+" lines");

		count = countLyrics("ROSE", "blackpink.bornpink.Song1");
		System.out.println("ROSE sang "+count+" lines");

		count = countLyrics("LALISA", "blackpink.bornpink.Song1");
		System.out.println("LALISA sang "+count+" lines");

	}

	
	private static int countLyrics(String singer, String song) throws Exception
	{
		return -1;
	}
}
